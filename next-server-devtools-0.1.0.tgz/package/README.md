# next-server-devtools

A Network tab for your Next.js **server**. In development, a pill in the corner
opens a panel with:

- **Network**: every `fetch` your server makes, grouped into a waterfall per page
  load, so calls that wait on each other stand out.
- **Logs**: server and browser console output in one list.

It records nothing in production, and nothing leaves your machine.

Requires Next.js 16+, React 19.2+ and the Node.js runtime.

## Setup

An install and five small files. Each step says why it exists.

### 1. Install

```sh
bun add next-server-devtools
```

In this repo it is a workspace package: `"next-server-devtools": "workspace:*"`.

### 2. Let Next compile it

The package ships TypeScript source.

```ts
// next.config.ts
const nextConfig: NextConfig = {
  transpilePackages: ["next-server-devtools"],
};
```

### 3. Record on the server

`instrumentation.ts` runs once when the server starts, before Next wraps
`fetch`. That puts the recorder under Next's cache, so a cache hit is not
recorded as a call.

```ts
// instrumentation.ts
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { registerDevtools } = await import("next-server-devtools/server");
    registerDevtools();
  }
}
```

### 4. Record in the browser

`instrumentation-client.ts` runs before hydration, so logs from the first render
are caught.

```ts
// instrumentation-client.ts
import { captureBrowserLogs } from "next-server-devtools/browser";

if (process.env.NODE_ENV === "development") captureBrowserLogs();
```

### 5. Add the feed

The panel reads recorded calls from this route. `next dev` listens on every
network interface, so anyone on your Wi-Fi can reach it. Pass `authorize` to
check a session.

```ts
// app/api/devtools/route.ts
import { createDevtoolsRoute } from "next-server-devtools/server";

const route = createDevtoolsRoute({
  authorize: async (request) =>
    Boolean(request.headers.get("cookie")?.includes("session=")),
});

export const GET = route.GET;
export const DELETE = route.DELETE;
```

### 6. Render the panel

In the root layout, or any layout that wraps the pages you want to inspect.
Import it **dynamically, behind `NODE_ENV`**: with a plain `import` at the top,
production builds still send the panel's code (about 26 kB) to every page,
even though it never renders.

```tsx
// app/layout.tsx
export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        {children}
        {await devtools()}
      </body>
    </html>
  );
}

async function devtools() {
  if (process.env.NODE_ENV === "development") {
    const { DevtoolsPanel } = await import("next-server-devtools/panel");
    return <DevtoolsPanel />;
  }
  return null;
}
```

Restart `next dev`: `next.config.ts` and `instrumentation.ts` are only read at
startup.

## Using it

Click the **Network** pill at the bottom right, or press **Alt+Shift+N**.
Escape leaves a call, then closes the panel. The panel does not block the page,
so you can keep clicking around while it is open.

**Network.** Each row is one burst of calls: the calls made while rendering a
page, or an action and the refresh after it. Its timeline has one line per call.

- **N in sequence** is the longest run of calls where each started after the one
  before finished. Each one costs a full round trip, so 3 or more turns amber.
- Click a row to list its calls. Click a call for its URL, timing, headers and
  bodies, and to copy it as cURL or JSON.
- Search and the status filters open every burst, so matches are never hidden.

**Logs.** Server and browser console output, newest first. Filter by source or
level, search, and click a row for the full arguments and stack.

**Pause** holds new entries until you resume. **Clear** empties the current
view in every open tab.

A red badge on the pill counts errors (failed calls and `console.error`) that
arrived since you last opened it.

## Adding what only your code knows

The recorder sees the HTTP exchange. Your API client knows more: a 200 whose
body failed its schema, or an error code from a problem document. Add it with
`annotateCall`. It matches the latest call with the same URL and
`x-request-id` header, so send one.

```ts
import { annotateCall } from "next-server-devtools/server";

const response = await fetch(url, { headers: { "x-request-id": requestId } });
const parsed = schema.safeParse(await response.json());
if (!parsed.success) {
  annotateCall(
    { url, requestId },
    { outcome: "malformed", issues: parsed.error.issues },
  );
}
```

It does nothing when the devtools are off, so it is safe to leave in production
code.

## Options

### `registerDevtools(options)`

| Option           | Default                      | What it does                                 |
| ---------------- | ---------------------------- | -------------------------------------------- |
| `enabled`        | `NODE_ENV === "development"` | Off means nothing is wrapped or recorded.    |
| `ignore`         | none                         | `(url: URL) => boolean`: calls to leave out. |
| `captureConsole` | `true`                       | Copy server console output to Logs.          |

### `createDevtoolsRoute(options)`

| Option      | Default                      | What it does                                                   |
| ----------- | ---------------------------- | -------------------------------------------------------------- |
| `enabled`   | `NODE_ENV === "development"` | Off answers 404.                                               |
| `authorize` | none                         | `(request) => boolean \| Promise<boolean>`; false answers 401. |

### `<DevtoolsPanel />`

| Prop           | Default           | What it does                                                                           |
| -------------- | ----------------- | -------------------------------------------------------------------------------------- |
| `endpoint`     | `"/api/devtools"` | Where the route from step 5 lives.                                                     |
| `bottom`       | `16`              | The pill's distance from the bottom of the window, in px.                              |
| `shortenPaths` | none              | `{ pattern, replacement }[]`, applied to paths in the list.                            |
| `colorScheme`  | `"inherit"`       | `"inherit"` follows the page's `color-scheme`; or `"light"`, `"dark"`, `"light dark"`. |

`shortenPaths` keeps long ids from pushing the useful part of a path off screen:

```tsx
<DevtoolsPanel
  shortenPaths={[
    { pattern: "/organizations/[^/?]+", replacement: "/organizations/:org" },
  ]}
/>
```

## What is recorded

- **Calls:** every server-side `fetch` that reaches the network. Cache hits and
  deduplicated requests are not recorded, because they never leave the server;
  nor is `next dev`'s own traffic (telemetry and its version check).
- **Bodies:** JSON and plain-text bodies only. Event streams and downloads are
  never read, so recording cannot hold them up.
- **Logs:** `console.debug`, `log`, `info`, `warn` and `error` on the server and
  in the browser, plus uncaught errors and rejected promises in the browser.
  The terminal and the browser console still print everything as usual.

The last 500 calls and 500 logs are kept in memory, per server process. A dev
server restart empties them, and the panel reconnects on its own.

## What is redacted

Server calls and server logs are redacted **before** they are stored, because
they are sent to the browser:

- **Keys**, ignoring case and separators. Anything containing `password`,
  `passcode`, `secret`, `token`, `privatekey`, `apikey`, `authorization`,
  `cookie`, `cvv`, `cvc`, `cardnumber`, `encryptionkey` or `signature`, and keys
  named exactly `pin`, `pan`, `otp`, `card`, `expiry`, `expirymonth`,
  `expiryyear` or `client`. In a request body `code` is redacted too (usually an
  OTP there); in a response it is kept (usually an error code).
- **Values** anywhere: PEM private keys, JWTs, and 13–19 digit runs (card
  numbers keep their last four).
- **Size:** strings are cut at 4,000 characters, arrays at 200 items, nesting at
  12 levels.

**Copy as cURL** puts `$TOKEN` in place of the bearer token. Other redacted
values stay redacted, so those calls will not replay as they are.

Browser logs are not redacted. They never leave the tab they came from.

## Production

Nothing runs in production:

- `registerDevtools` and the route are off unless `NODE_ENV` is development.
- `captureBrowserLogs` returns straight away, and the bundler drops the import.
- Import `<DevtoolsPanel />` behind `NODE_ENV`, as in step 6, and production
  builds leave it out entirely.

## Limits

- **Grouping is by timing.** Calls that overlap, or start within 150ms of the
  previous one ending, form one burst. Two tabs loading at the same moment
  share a burst.
- **Console source links.** Wrapping `console` makes Chrome DevTools show this
  package as the source of browser logs. Right-click the file name in the
  console and choose **Add script to ignore list** to get the real caller back.
- **Edge runtime:** not recorded. `registerDevtools` needs Node.js.

## How it works

```
server fetch ─┐                                  ┌─► Network view
              ├─► redact ─► buffer (globalThis) ─┤   (via GET ?stream=1, SSE)
console.*   ──┘                                  └─► Logs view
browser console ─► buffer in the tab ─────────────► Logs view
```

The buffer lives on `globalThis`, because route handlers, Server Components and
actions load separate copies of each module. The panel renders into a shadow
root with its own CSS, so the page's styles cannot change it and its styles
cannot reach the page.
