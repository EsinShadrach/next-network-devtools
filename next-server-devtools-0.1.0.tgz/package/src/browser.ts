import {
  LOG_LEVELS,
  formatLog,
  toLoggable,
  type LogEntry,
  type LogLevel,
} from "./shared";

/**
 * This tab's console output for the Logs tab. It never leaves the browser.
 * Kept on globalThis so instrumentation-client.ts and the panel share one store.
 */

const LIMIT = 500;

type Store = {
  logs: LogEntry[];
  /** Recorded since listeners were last told. */
  pending: LogEntry[];
  listeners: Set<(logs: LogEntry[]) => void>;
  next: number;
  captured: boolean;
  flushQueued: boolean;
};

const KEY = Symbol.for("next-server-devtools.browser");

function store(): Store {
  const scope = globalThis as unknown as Record<symbol, Store | undefined>;
  scope[KEY] ??= {
    logs: [],
    pending: [],
    listeners: new Set(),
    next: 1,
    captured: false,
    flushQueued: false,
  };
  return scope[KEY];
}

/** Call from instrumentation-client.ts, so logs from before hydration are caught. */
export function captureBrowserLogs(): void {
  if (process.env.NODE_ENV !== "development") return;
  const buffer = store();
  if (buffer.captured) return;
  buffer.captured = true;

  for (const level of LOG_LEVELS) {
    const original = console[level];
    console[level] = (...args: unknown[]) => {
      original.apply(console, args);
      record(level, args);
    };
  }
  window.addEventListener("error", (event) =>
    record("error", ["Uncaught", event.error ?? event.message]),
  );
  window.addEventListener("unhandledrejection", (event) =>
    record("error", ["Uncaught (in promise)", event.reason]),
  );
}

function record(level: LogLevel, raw: unknown[]): void {
  // React replays server logs behind a "%c%s%c" badge; the server side has them.
  if (typeof raw[0] === "string" && raw[0].startsWith("%c%s%c")) return;
  try {
    const args = raw.map((arg) => toLoggable(arg));
    const message = formatLog(args).trim();
    if (!message || /^\[(Fast Refresh|HMR)\]/.test(message)) return;

    const buffer = store();
    const log: LogEntry = {
      id: buffer.next++,
      at: new Date().toISOString(),
      source: "browser",
      level,
      message: message.slice(0, 1000),
      args,
    };
    buffer.logs.push(log);
    if (buffer.logs.length > LIMIT) {
      buffer.logs.splice(0, buffer.logs.length - LIMIT);
    }
    buffer.pending.push(log);
    // Deferred: a log written mid-render must not set the panel's state.
    if (!buffer.flushQueued) {
      buffer.flushQueued = true;
      setTimeout(flush, 0);
    }
  } catch {
    // The console already printed it.
  }
}

function flush(): void {
  const buffer = store();
  const batch = buffer.pending;
  buffer.pending = [];
  buffer.flushQueued = false;
  for (const listener of buffer.listeners) listener(batch);
}

/**
 * Called with what is already logged, then with each batch of new logs. A batch
 * can repeat logs already delivered, so listeners dedupe by id.
 */
export function subscribeBrowserLogs(
  listener: (logs: LogEntry[]) => void,
): () => void {
  const buffer = store();
  buffer.listeners.add(listener);
  setTimeout(() => {
    if (buffer.listeners.has(listener)) listener([...buffer.logs]);
  }, 0);
  return () => buffer.listeners.delete(listener);
}

export function clearBrowserLogs(): void {
  const buffer = store();
  buffer.logs = [];
  buffer.pending = [];
}
