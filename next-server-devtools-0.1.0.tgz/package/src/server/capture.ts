import "server-only";
import { inspect } from "node:util";
import { LOG_LEVELS, toLoggable } from "../shared";
import { recordCall, recordLog, store } from "./store";

/**
 * Wraps global fetch. Installed before Next patches fetch on the first render,
 * so it sits under Next's cache: a cache hit is not a call and is not recorded.
 */
export function captureFetch(ignore?: (url: URL) => boolean): void {
  const buffer = store();
  if (buffer.fetchCaptured) return;
  buffer.fetchCaptured = true;

  const original = globalThis.fetch;
  globalThis.fetch = async (input, init) => {
    let url: URL;
    try {
      url = new URL(input instanceof Request ? input.url : String(input));
    } catch {
      return original(input, init);
    }
    if (isNextOwnCall(url) || ignore?.(url)) return original(input, init);

    // Read from input and init rather than new Request(), which would consume a
    // streamed body the real call still needs.
    const headers = new Headers(
      input instanceof Request ? input.headers : undefined,
    );
    new Headers(init?.headers).forEach((value, name) =>
      headers.set(name, value),
    );
    const method = (
      init?.method ?? (input instanceof Request ? input.method : "GET")
    ).toUpperCase();
    const startedAt = Date.now();
    const call = {
      at: new Date(startedAt).toISOString(),
      method,
      url: url.href,
      path: url.pathname + url.search,
      requestId: headers.get("x-request-id") ?? undefined,
      requestHeaders: Object.fromEntries(headers),
      requestBody: describeBody(init?.body),
    };

    let response: Response;
    try {
      response = await original(input, init);
    } catch (error) {
      recordCall({
        ...call,
        status: null,
        outcome: "unreachable",
        durationMs: Date.now() - startedAt,
        cause: error instanceof Error ? error.name : "unknown",
      });
      throw error;
    }

    const contentType = response.headers.get("content-type") ?? "";
    const isStream = contentType.includes("text/event-stream");
    let responseBody: unknown;
    let responseSize: number | undefined;
    // Only bodies that end and read as text: never a stream or a download.
    if (!isStream && /json|text\/plain/.test(contentType)) {
      try {
        const text = await response.clone().text();
        responseSize = Buffer.byteLength(text);
        responseBody = parseJson(text);
      } catch {
        // Aborted mid-body; the caller sees the same error.
      }
    }

    // Recorded before the caller gets the response, so annotateCall finds it.
    recordCall({
      ...call,
      status: response.status,
      outcome: isStream ? "stream" : response.status < 400 ? "ok" : "rejected",
      durationMs: Date.now() - startedAt,
      contentType: contentType || undefined,
      responseBody,
      responseSize,
    });
    return response;
  };
}

/** Copies every server console call into the Logs tab. The terminal still prints them. */
export function captureConsole(): void {
  const buffer = store();
  if (buffer.consoleCaptured) return;
  buffer.consoleCaptured = true;

  for (const level of LOG_LEVELS) {
    const original = console[level].bind(console);
    console[level] = (...args: unknown[]) => {
      original(...args);
      if (buffer.recording) return;
      buffer.recording = true;
      try {
        // inspect() rather than .stack: next dev source-maps it.
        recordLog(
          level,
          args.map((arg) =>
            toLoggable(arg instanceof Error ? inspect(arg) : arg),
          ),
        );
      } catch {
        // A log that cannot be recorded still reached the terminal.
      } finally {
        buffer.recording = false;
      }
    };
  }
}

/** next dev's own traffic, not the app's: telemetry and its version check. */
function isNextOwnCall(url: URL): boolean {
  return (
    url.hostname === "telemetry.nextjs.org" ||
    (url.hostname === "registry.npmjs.org" &&
      url.pathname.startsWith("/-/package/next/"))
  );
}

function describeBody(body: RequestInit["body"]): unknown {
  if (body === undefined || body === null) return undefined;
  if (typeof body === "string") return parseJson(body);
  if (body instanceof URLSearchParams) return body.toString();
  return `[${body.constructor.name}]`;
}

function parseJson(text: string): unknown {
  if (!text) return undefined;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
