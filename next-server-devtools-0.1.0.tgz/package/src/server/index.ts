import "server-only";
import type { Change } from "../shared";
import { captureConsole, captureFetch } from "./capture";
import { clear, store, subscribe } from "./store";

export { annotateCall } from "./store";
export type { CallAnnotation, LogEntry, NetworkEntry } from "../shared";

const isDevelopment = () => process.env.NODE_ENV === "development";

export type DevtoolsOptions = {
  /** Default: only under `next dev`. */
  enabled?: boolean;
  /** Calls to leave out, e.g. an analytics endpoint. */
  ignore?: (url: URL) => boolean;
  /** Copy server console output into the Logs tab. Default true. */
  captureConsole?: boolean;
};

/** Call from `register()` in instrumentation.ts, on the nodejs runtime. */
export function registerDevtools({
  enabled = isDevelopment(),
  ignore,
  captureConsole: logs = true,
}: DevtoolsOptions = {}): void {
  if (!enabled) return;
  captureFetch(ignore);
  if (logs) captureConsole();
}

export type RouteOptions = {
  /** Default: only under `next dev`. Anything else answers 404. */
  enabled?: boolean;
  /** `next dev` listens on every interface; check a session or a header here. */
  authorize?: (request: Request) => boolean | Promise<boolean>;
};

/**
 * The feed the panel reads. `GET` returns JSON, or with `?stream=1` sends SSE:
 * a `snapshot`, then an event per change. `DELETE` clears calls, or with
 * `?kind=logs` the logs.
 */
export function createDevtoolsRoute({
  enabled = isDevelopment(),
  authorize,
}: RouteOptions = {}) {
  async function guard(request: Request): Promise<Response | null> {
    if (!enabled) return new Response("Not found", { status: 404 });
    if (authorize && !(await authorize(request))) {
      return new Response("Unauthorized", { status: 401 });
    }
    return null;
  }

  async function GET(request: Request): Promise<Response> {
    const refused = await guard(request);
    if (refused) return refused;

    const snapshot = () => ({
      entries: [...store().entries],
      logs: [...store().logs],
    });
    if (new URL(request.url).searchParams.get("stream") !== "1") {
      return Response.json(snapshot(), {
        headers: { "cache-control": "no-store" },
      });
    }

    const encoder = new TextEncoder();
    let unsubscribe = () => {};
    let keepAlive: ReturnType<typeof setInterval> | undefined;

    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        const send = (event: string, data: unknown) =>
          controller.enqueue(
            encoder.encode(
              `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`,
            ),
          );
        const stop = () => {
          unsubscribe();
          clearInterval(keepAlive);
          try {
            controller.close();
          } catch {
            // Already closed.
          }
        };

        send("snapshot", snapshot());
        unsubscribe = subscribe((change: Change) => {
          if (change.type === "clear") send("clear", change.kind);
          else if (change.type === "log") send("log", change.log);
          else send(change.type, change.entry);
        });
        // A comment every 15s, so proxies do not treat the idle stream as dead.
        keepAlive = setInterval(
          () => controller.enqueue(encoder.encode(": keep-alive\n\n")),
          15_000,
        );
        request.signal.addEventListener("abort", stop);
      },
      cancel() {
        unsubscribe();
        clearInterval(keepAlive);
      },
    });

    return new Response(stream, {
      headers: {
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-cache, no-store, no-transform",
        connection: "keep-alive",
      },
    });
  }

  async function DELETE(request: Request): Promise<Response> {
    const refused = await guard(request);
    if (refused) return refused;
    const kind = new URL(request.url).searchParams.get("kind");
    clear(kind === "logs" ? "logs" : "network");
    return new Response(null, { status: 204 });
  }

  return { GET, DELETE };
}
