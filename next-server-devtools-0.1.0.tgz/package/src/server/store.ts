import "server-only";
import {
  formatLog,
  type CallAnnotation,
  type Change,
  type LogEntry,
  type LogLevel,
  type NetworkEntry,
} from "../shared";

const LIMIT = 500;
const MAX_STRING = 4000;

type Store = {
  entries: NetworkEntry[];
  logs: LogEntry[];
  listeners: Set<(change: Change) => void>;
  next: number;
  nextLog: number;
  fetchCaptured: boolean;
  consoleCaptured: boolean;
  /** Set while a log is being recorded, so recording never records itself. */
  recording: boolean;
};

// On globalThis: route handlers, Server Components and actions load separate
// module instances, and they must all share one buffer.
const KEY = Symbol.for("next-server-devtools");
const scope = globalThis as unknown as Record<symbol, Store | undefined>;

export function store(): Store {
  scope[KEY] ??= {
    entries: [],
    logs: [],
    listeners: new Set(),
    next: 1,
    nextLog: 1,
    fetchCaptured: false,
    consoleCaptured: false,
    recording: false,
  };
  return scope[KEY];
}

export function recordCall(entry: Omit<NetworkEntry, "id">): void {
  const buffer = store();
  const recorded: NetworkEntry = {
    ...entry,
    id: buffer.next++,
    requestHeaders: redactHeaders(entry.requestHeaders),
    requestBody:
      entry.requestBody === undefined
        ? undefined
        : redact(entry.requestBody, true),
    responseBody:
      entry.responseBody === undefined
        ? undefined
        : redact(entry.responseBody, false),
  };
  buffer.entries.push(recorded);
  if (buffer.entries.length > LIMIT) {
    buffer.entries.splice(0, buffer.entries.length - LIMIT);
  }
  broadcast({ type: "entry", entry: recorded });
}

/**
 * Adds detail to the latest recorded call with this url and x-request-id, for
 * what only the caller knows: a body that failed its schema, an error code.
 * A no-op when nothing matches or the devtools are off.
 */
export function annotateCall(
  match: { url: string; requestId: string },
  annotation: CallAnnotation,
): void {
  const buffer = scope[KEY];
  if (!buffer) return;
  const index = buffer.entries.findLastIndex(
    (entry) => entry.url === match.url && entry.requestId === match.requestId,
  );
  if (index === -1) return;
  const entry = {
    ...buffer.entries[index],
    ...annotation,
    issues:
      annotation.issues === undefined
        ? buffer.entries[index].issues
        : redact(annotation.issues, false),
  };
  buffer.entries[index] = entry;
  broadcast({ type: "update", entry });
}

/** Takes args already made loggable; redacts them before formatting. */
export function recordLog(level: LogLevel, loggable: unknown[]): void {
  const args = loggable.map((arg) => redact(arg, false));
  const message = formatLog(args).trim();
  // next dev echoes browser warnings as "[browser] …"; the browser side has them.
  if (!message || message.startsWith("[browser]")) return;

  const buffer = store();
  const recorded: LogEntry = {
    id: buffer.nextLog++,
    at: new Date().toISOString(),
    source: "server",
    level,
    message: message.slice(0, 1000),
    args,
  };
  buffer.logs.push(recorded);
  if (buffer.logs.length > LIMIT) {
    buffer.logs.splice(0, buffer.logs.length - LIMIT);
  }
  broadcast({ type: "log", log: recorded });
}

export function clear(kind: "network" | "logs"): void {
  const buffer = store();
  if (kind === "logs") buffer.logs = [];
  else buffer.entries = [];
  broadcast({ type: "clear", kind });
}

export function subscribe(listener: (change: Change) => void): () => void {
  const buffer = store();
  buffer.listeners.add(listener);
  return () => buffer.listeners.delete(listener);
}

function broadcast(change: Change): void {
  for (const listener of store().listeners) {
    try {
      listener(change);
    } catch {
      // A closed stream; its own cleanup unsubscribes it.
    }
  }
}

/**
 * Secret keys, matched with case and separators ignored: families by substring,
 * short names exactly.
 */
const SECRET_PARTS = [
  "password",
  "passcode",
  "secret",
  "token",
  "privatekey",
  "apikey",
  "authorization",
  "cookie",
  "cvv",
  "cvc",
  "cardnumber",
  "encryptionkey",
  "signature",
];
const SECRET_EXACT = new Set([
  "pin",
  "pan",
  "otp",
  "card",
  "expiry",
  "expirymonth",
  "expiryyear",
  "client",
]);
/** Secret in requests only: a request's `code` is an OTP; a response's is an error code. */
const INPUT_ONLY = new Set(["code"]);

const REDACTED = "[redacted]";

function isSecretKey(key: string, isInput: boolean): boolean {
  const flat = key.toLowerCase().replace(/[^a-z]/g, "");
  if (SECRET_EXACT.has(flat)) return true;
  if (isInput && INPUT_ONLY.has(flat)) return true;
  return SECRET_PARTS.some((part) => flat.includes(part));
}

/** Secrets that turn up as values under keys nobody would think to list. */
export function scrubString(value: string): string {
  let out = value
    .replace(
      /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
      "[redacted private key]",
    )
    .replace(
      /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+/g,
      "[redacted jwt]",
    )
    // Card-number-shaped digit runs keep only their last four.
    .replace(/\b\d{13,19}\b/g, (digits) => `•••• ${digits.slice(-4)}`);
  if (out.length > MAX_STRING) {
    out = `${out.slice(0, MAX_STRING)}… [${out.length - MAX_STRING} more characters]`;
  }
  return out;
}

function redact(value: unknown, isInput: boolean, depth = 0): unknown {
  if (depth > 12) return "[too deep]";
  if (typeof value === "string") return scrubString(value);
  if (Array.isArray(value)) {
    const shown = value
      .slice(0, 200)
      .map((item) => redact(item, isInput, depth + 1));
    return value.length > 200
      ? [...shown, `[${value.length - 200} more items]`]
      : shown;
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        isSecretKey(key, isInput) ? REDACTED : redact(item, isInput, depth + 1),
      ]),
    );
  }
  return value;
}

function redactHeaders(headers: Record<string, string>) {
  return Object.fromEntries(
    Object.entries(headers).map(([name, value]) => [
      name,
      isSecretKey(name, true) ? REDACTED : value,
    ]),
  );
}
