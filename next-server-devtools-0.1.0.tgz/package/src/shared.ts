export type Outcome =
  "ok" | "rejected" | "unreachable" | "malformed" | "stream";

export type NetworkEntry = {
  /** Increases per server process. */
  id: number;
  at: string;
  method: string;
  url: string;
  /** Path and query only. */
  path: string;
  /** Null when there was no response (timeout, refused socket). */
  status: number | null;
  outcome: Outcome;
  durationMs: number;
  /** The request's x-request-id header, when it sent one. */
  requestId?: string;
  /** Set with annotateCall, e.g. the upstream's own request id. */
  upstreamRequestId?: string;
  code?: string;
  /** e.g. TimeoutError, TypeError. */
  cause?: string;
  contentType?: string;
  requestHeaders: Record<string, string>;
  requestBody?: unknown;
  responseBody?: unknown;
  /** Response body size before redaction. */
  responseSize?: number;
  issues?: unknown;
};

/** What annotateCall can add to a recorded call. */
export type CallAnnotation = Partial<
  Pick<NetworkEntry, "outcome" | "code" | "upstreamRequestId" | "issues">
>;

export const LOG_LEVELS = ["debug", "log", "info", "warn", "error"] as const;
export type LogLevel = (typeof LOG_LEVELS)[number];

export type LogEntry = {
  /** Increases per process on the server, per tab in the browser. */
  id: number;
  at: string;
  source: "server" | "browser";
  level: LogLevel;
  /** One line, for the list and search. */
  message: string;
  /** JSON-safe; server args are redacted. */
  args: unknown[];
};

export type Change =
  | { type: "entry"; entry: NetworkEntry }
  | { type: "update"; entry: NetworkEntry }
  | { type: "log"; log: LogEntry }
  | { type: "clear"; kind: "network" | "logs" };

export type StatusClass = "2xx" | "3xx" | "4xx" | "5xx" | "failed";

/** No status at all counts as `failed`. */
export function statusClass(entry: NetworkEntry): StatusClass {
  if (entry.status === null || entry.outcome === "malformed") return "failed";
  if (entry.status >= 500) return "5xx";
  if (entry.status >= 400) return "4xx";
  if (entry.status >= 300) return "3xx";
  return "2xx";
}

/**
 * The call as a curl command. A bearer token becomes `$TOKEN`; other redacted
 * values stay redacted, so such calls will not replay as-is.
 */
export function asCurl(entry: NetworkEntry): string {
  const quote = (value: string) => `'${value.replaceAll("'", `'\\''`)}'`;
  const parts = [`curl -X ${entry.method} ${quote(entry.url)}`];
  for (const [name, value] of Object.entries(entry.requestHeaders)) {
    const shown =
      name.toLowerCase() === "authorization" ? "Bearer $TOKEN" : value;
    parts.push(`-H ${quote(`${name}: ${shown}`)}`);
  }
  if (entry.requestBody !== undefined) {
    const body =
      typeof entry.requestBody === "string"
        ? entry.requestBody
        : JSON.stringify(entry.requestBody);
    parts.push(`--data ${quote(body)}`);
  }
  return parts.join(" \\\n  ");
}

const ANSI = /\u001b\[[\d;]*m/g;

/** A console argument as JSON-safe data. Errors become their stack. */
export function toLoggable(
  value: unknown,
  depth = 0,
  seen = new WeakSet<object>(),
): unknown {
  if (typeof value === "string") return value.replace(ANSI, "");
  if (typeof value === "number" || typeof value === "boolean") return value;
  if (value === null) return null;
  if (value === undefined) return "undefined";
  if (typeof value === "bigint") return `${value}n`;
  if (typeof value === "symbol") return value.toString();
  if (typeof value === "function") {
    return `[Function ${value.name || "anonymous"}]`;
  }
  if (value instanceof Error) {
    return value.stack?.includes(value.message)
      ? value.stack
      : `${value.name}: ${value.message}\n${value.stack ?? ""}`.trim();
  }
  if (value instanceof Date) return value.toString();
  if (typeof Element !== "undefined" && value instanceof Element) {
    return `<${value.tagName.toLowerCase()}${value.id ? `#${value.id}` : ""}>`;
  }
  if (typeof value !== "object") return String(value);
  if (seen.has(value)) return "[Circular]";
  if (depth >= 6) return Array.isArray(value) ? "[Array]" : "[Object]";

  seen.add(value);
  const next = (item: unknown) => toLoggable(item, depth + 1, seen);
  try {
    if (value instanceof Map) return [...value].slice(0, 100).map(next);
    if (value instanceof Set) return [...value].slice(0, 100).map(next);
    if (Array.isArray(value)) return value.slice(0, 100).map(next);
    return Object.fromEntries(
      Object.entries(value)
        .slice(0, 100)
        .map(([key, item]) => [key, next(item)]),
    );
  } catch {
    return "[Unreadable]";
  } finally {
    seen.delete(value);
  }
}

/** Formats loggable args the way the console prints them, `%s` and all. */
export function formatLog(args: unknown[], pretty = false): string {
  const show = (value: unknown) =>
    typeof value === "string"
      ? value
      : (JSON.stringify(value, null, pretty ? 2 : undefined) ?? String(value));
  const [first, ...rest] = args;
  if (typeof first !== "string") return args.map(show).join(" ");

  const head = first.replace(/%[sdifoOjc%]/g, (token) => {
    if (token === "%%") return "%";
    if (rest.length === 0) return token;
    const value = rest.shift();
    return token === "%c" ? "" : show(value);
  });
  return [head, ...rest.map(show)].join(" ");
}
