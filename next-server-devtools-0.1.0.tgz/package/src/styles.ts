/** The panel's CSS. It lives in the panel's shadow root, so nothing leaks either way. */
export const CSS = /* css */ `
:host {
  --surface: light-dark(#ffffff, #0d0f14);
  --ink: light-dark(#0a0c10, #eceae5);
  --grey-400: light-dark(#94999e, #6b727d);
  --grey-550: light-dark(#5d646e, #8b929c);
  --grey-600: light-dark(#4d535c, #a7adb6);
  --grey-700: light-dark(#343840, #c3c8cf);
  --success-0: light-dark(#e7fef8, #14392f);
  --success-100: #40c4aa;
  --success-200: light-dark(#287f6e, #2ecc8f);
  --warning-0: light-dark(#fff6e0, #38290d);
  --warning-100: #e0a63f;
  --warning-200: light-dark(#956321, #e8b45c);
  --error-0: light-dark(#feeff2, #3a1119);
  --error-100: light-dark(#df1c41, #ff5470);
  --error-200: light-dark(#95122b, #ff8fa3);
  --primary-0: light-dark(#edf2ff, #16203a);
  --primary-50: light-dark(#a9c0ff, #2c417a);
  --primary-200: light-dark(#1440c4, #7c9cff);
  --accent: light-dark(#1e56ff, #5b86ff);
  --line: color-mix(in srgb, var(--ink) 10%, transparent);
  --line-strong: color-mix(in srgb, var(--ink) 25%, transparent);
  --line-soft: color-mix(in srgb, var(--ink) 5%, transparent);
  --wash: color-mix(in srgb, var(--ink) 3%, transparent);
  --wash-soft: color-mix(in srgb, var(--ink) 2%, transparent);
  --ease: cubic-bezier(0.23, 1, 0.32, 1);
  --sans: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --mono: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  --radius: 10px;
}

*, *::before, *::after { box-sizing: border-box; }
[hidden] { display: none !important; }
.root {
  font-family: var(--sans);
  font-size: 12px;
  line-height: 1.5;
  color: var(--ink);
  letter-spacing: normal;
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
button {
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  background: none;
  border: 0;
  margin: 0;
  padding: 0;
  cursor: pointer;
}
input { font: inherit; color: inherit; margin: 0; }
ol { list-style: none; margin: 0; padding: 0; }
h2, h3, p, pre, dl, dd { margin: 0; }
svg { display: block; flex-shrink: 0; }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

.num { color: var(--grey-550); font-variant-numeric: tabular-nums; }
.right { text-align: right; }
.truncate { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.muted-text { color: var(--grey-550); }

.pill {
  position: fixed;
  right: 12px;
  z-index: 2147483001;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: var(--surface);
  font-weight: 500;
  box-shadow: 0 4px 16px -4px rgb(10 12 16 / 0.25);
  transition: border-color 150ms ease, translate 300ms var(--ease);
}
.pill:hover { border-color: var(--line-strong); }
.pill.open { translate: -760px 0; }
@media (max-width: 1023px) { .pill.open { translate: none; } }
.dot { width: 6px; height: 6px; border-radius: 999px; background: var(--grey-400); }
.dot.live { background: var(--success-100); }
.badge {
  padding: 0 6px;
  border-radius: 999px;
  background: var(--error-100);
  color: #fff;
  font-size: 10px;
  font-weight: 600;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
}

.panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 2147483000;
  display: flex;
  flex-direction: column;
  width: 760px;
  max-width: 100%;
  border-left: 1px solid var(--line);
  background: var(--surface);
  box-shadow: -12px 0 40px -12px rgb(10 12 16 / 0.25);
  translate: 100% 0;
  transition: translate 300ms var(--ease);
}
.panel.open { translate: none; }

.header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--line);
}
.header .dot { width: 8px; height: 8px; }
.views { display: flex; gap: 12px; }
.view {
  display: inline-flex;
  align-items: baseline;
  gap: 6px;
  color: var(--grey-550);
  font-size: 14px;
  font-weight: 600;
  letter-spacing: -0.056px;
  transition: color 150ms ease;
}
.view:hover, .view[aria-selected="true"] { color: var(--ink); }
.view-count { color: var(--grey-550); font-size: 12px; font-weight: 400; font-variant-numeric: tabular-nums; }
.subtitle { color: var(--grey-550); }
@media (max-width: 639px) { .subtitle { display: none; } }
.actions { display: flex; flex-shrink: 0; align-items: center; gap: 6px; margin-left: auto; }
.button {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--surface);
  transition: border-color 150ms ease;
}
.button:hover { border-color: var(--line-strong); }

.toolbar {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 10px 16px;
  border-bottom: 1px solid var(--line);
}
.search {
  width: 100%;
  height: 34px;
  padding: 0 12px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--surface);
  outline: none;
}
.search::placeholder { color: var(--grey-550); }
.search:focus { border-color: var(--accent); }
.chips { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 10px;
  border: 1px solid var(--line);
  border-radius: 999px;
  color: var(--grey-600);
  transition: border-color 150ms ease, background-color 150ms ease, color 150ms ease;
}
.chip:hover { border-color: var(--line-strong); }
.chip[aria-pressed="true"] { border-color: var(--accent); background: var(--primary-0); color: var(--primary-200); }
.divider { width: 1px; height: 16px; margin: 0 4px; background: var(--line); }

.list { flex: 1; min-height: 0; overflow-y: auto; }
.empty { padding: 40px 16px; color: var(--grey-550); line-height: 1.625; text-align: center; }
.burst, .log { border-bottom: 1px solid var(--line-soft); }
.burst-row, .call, .log-row {
  display: grid;
  align-items: center;
  gap: 8px;
  width: 100%;
  transition: background-color 150ms ease;
}
.burst-row:hover, .call:hover, .log-row:hover { background: var(--wash); }
.burst-row { grid-template-columns: 1rem 5.5rem 10rem minmax(0, 1fr) 4rem; padding: 10px 16px; }
.chevron { width: 14px; height: 14px; color: var(--grey-550); transition: rotate 150ms var(--ease); }
.chevron.open { rotate: 90deg; }
.summary { font-variant-numeric: tabular-nums; }
.seq { color: var(--grey-550); }
.seq.slow { color: var(--warning-200); font-weight: 500; }
.timeline { display: flex; flex-direction: column; gap: 2px; }
.lane { position: relative; height: 4px; border-radius: 999px; background: var(--line-soft); }
.bar { position: absolute; top: 0; bottom: 0; min-width: 2px; border-radius: 999px; }
.bar.ok { background: var(--success-100); }
.bar.muted { background: var(--grey-400); }
.bar.warn { background: var(--warning-100); }
.bar.error { background: var(--error-100); }
.calls { border-top: 1px solid var(--line-soft); background: var(--wash-soft); }
.calls > li + li { border-top: 1px solid var(--line-soft); }
.call { grid-template-columns: 3.5rem 3.25rem 2.75rem minmax(0, 1fr) 4rem; padding: 8px 16px 8px 40px; }
.log-row { grid-template-columns: 5.5rem 3.75rem 2.75rem minmax(0, 1fr); padding: 8px 16px; }
.log-open { padding: 0 16px 12px; }

.tag {
  justify-self: start;
  padding: 2px 6px;
  border-radius: 6px;
  font-family: var(--mono);
  font-size: 10px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.upper { text-transform: uppercase; }
.tone-neutral { background: var(--line-soft); color: var(--grey-700); }
.tone-muted { background: var(--line-soft); color: var(--grey-550); }
.tone-ok { background: var(--success-0); color: var(--success-200); }
.tone-warn { background: var(--warning-0); color: var(--warning-200); }
.tone-error { background: var(--error-0); color: var(--error-200); }
.path { font-family: var(--mono); font-size: 11px; }

.view-body { display: flex; flex: 1; min-height: 0; flex-direction: column; }
.detail-top {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--line);
}
.line { display: flex; min-width: 0; align-items: center; gap: 8px; }
.push { display: flex; gap: 6px; margin-left: auto; }
.detail-path { min-width: 0; font-family: var(--mono); word-break: break-all; }
.tabs { display: flex; gap: 16px; }
.tab {
  margin-bottom: -12px;
  padding-bottom: 8px;
  border-bottom: 2px solid transparent;
  color: var(--grey-550);
  text-transform: capitalize;
  transition: color 150ms ease, border-color 150ms ease;
}
.tab:hover { color: var(--ink); }
.tab[aria-selected="true"] { border-color: var(--accent); color: var(--ink); font-weight: 500; }
.detail-body { flex: 1; min-height: 0; overflow-y: auto; padding: 12px 16px; }
.stack { display: flex; flex-direction: column; gap: 12px; }
.section { display: flex; flex-direction: column; gap: 6px; }
.section-title {
  color: var(--grey-550);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.025em;
  text-transform: uppercase;
}
.rows { display: grid; grid-template-columns: 9rem minmax(0, 1fr); gap: 6px 12px; }
.rows dt { color: var(--grey-550); }
.rows dd { min-width: 0; overflow-wrap: break-word; }
.mono { font-family: var(--mono); font-size: 11px; word-break: break-all; }
.json { position: relative; width: 100%; }
.json pre {
  overflow-x: auto;
  padding: 12px;
  border-radius: var(--radius);
  background: var(--wash);
  font-family: var(--mono);
  font-size: 11px;
  line-height: 1.625;
  white-space: pre;
}
.json-copy {
  position: absolute;
  top: 12px;
  right: 12px;
  display: inline-flex;
  padding: 2px 10px;
  border-radius: 999px;
  background: var(--primary-0);
  color: var(--primary-200);
  transition: background-color 150ms ease;
}
.json-copy:hover { background: var(--primary-50); }
.json-copy svg { width: 14px; height: 14px; }
.note { margin-top: 16px; color: var(--grey-550); font-size: 11px; line-height: 1.625; }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { transition: none !important; }
}
`;
