"use client";

import {
  useCallback,
  useEffect,
  useEffectEvent,
  useMemo,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ComponentProps,
  type ReactNode,
  type Ref,
} from "react";
import { createPortal } from "react-dom";
import { clearBrowserLogs, subscribeBrowserLogs } from "./browser";
import {
  asCurl,
  formatLog,
  statusClass,
  type LogEntry,
  type LogLevel,
  type NetworkEntry,
  type StatusClass,
} from "./shared";
import { CSS } from "./styles";

export type DevtoolsPanelProps = {
  /** Where the route from createDevtoolsRoute is mounted. Default "/api/devtools". */
  endpoint?: string;
  /** The pill's distance from the bottom of the window, in px. Default 16. */
  bottom?: number;
  /** Rewrites applied to paths in the list, e.g. to fold a long id. */
  shortenPaths?: { pattern: string; replacement: string }[];
  /** "inherit" follows the page's `color-scheme`. Default "inherit". */
  colorScheme?: "inherit" | "light" | "dark" | "light dark";
};

/**
 * Every fetch the server makes, grouped into a waterfall, and server and browser
 * logs. Rendered in a shadow root. Toggle with the pill or Alt+Shift+N.
 */
export function DevtoolsPanel({
  colorScheme = "inherit",
  ...props
}: DevtoolsPanelProps) {
  const [root, setRoot] = useState<ShadowRoot | null>(null);
  const attach = useCallback((host: HTMLDivElement | null) => {
    if (host) setRoot(host.shadowRoot ?? host.attachShadow({ mode: "open" }));
  }, []);

  return (
    <div
      ref={attach}
      data-next-server-devtools=""
      style={colorScheme === "inherit" ? undefined : { colorScheme }}
    >
      {root
        ? createPortal(
            <div className="root">
              <style>{CSS}</style>
              <Panel {...props} />
            </div>,
            root,
          )
        : null}
    </div>
  );
}

const LIMIT = 500;
const LOG_LIMIT = 1000;

type View = "network" | "logs";
type Filter = "all" | Exclude<StatusClass, "3xx">;
type Tab = "overview" | "request" | "response";
type SourceFilter = "all" | LogEntry["source"];
type LevelFilter = "all" | "error" | "warn";

const VIEWS: { id: View; label: string }[] = [
  { id: "network", label: "Network" },
  { id: "logs", label: "Logs" },
];

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "2xx", label: "2xx" },
  { id: "4xx", label: "4xx" },
  { id: "5xx", label: "5xx" },
  { id: "failed", label: "Failed" },
];

const SOURCE_FILTERS: { id: SourceFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "server", label: "Server" },
  { id: "browser", label: "Browser" },
];

const LEVEL_FILTERS: { id: LevelFilter; label: string }[] = [
  { id: "all", label: "All levels" },
  { id: "error", label: "Errors" },
  { id: "warn", label: "Warnings" },
];

function Panel({
  endpoint = "/api/devtools",
  bottom = 16,
  shortenPaths,
}: Omit<DevtoolsPanelProps, "colorScheme">) {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<View>("network");
  /** Newest first. */
  const [entries, setEntries] = useState<NetworkEntry[]>([]);
  /** Arrived while paused; merged in on resume. */
  const [held, setHeld] = useState<NetworkEntry[]>([]);
  /** Server and browser, newest first. */
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [heldLogs, setHeldLogs] = useState<LogEntry[]>([]);
  const [paused, setPaused] = useState(false);
  const [connected, setConnected] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  /** Bursts opened by hand; all open while a filter or search is on. */
  const [openBursts, setOpenBursts] = useState<ReadonlySet<number>>(new Set());
  const [tab, setTab] = useState<Tab>("overview");
  /** Error count when the panel was last opened. */
  const [seenErrors, setSeenErrors] = useState(0);

  // Read inside the stream's callbacks, which are bound once.
  const pausedRef = useRef(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const logSearchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    pausedRef.current = paused;
  }, [paused]);

  /** EventSource reconnects on dev-server restarts, and the snapshot replaces the list. */
  useEffect(() => {
    const addLogs = (added: LogEntry[]) => {
      if (pausedRef.current) {
        setHeldLogs((current) => mergeLogs(current, added));
      } else {
        setLogs((current) => mergeLogs(current, added));
      }
    };
    const read = <T,>(event: Event) =>
      JSON.parse((event as MessageEvent<string>).data) as T;

    const source = new EventSource(`${endpoint}?stream=1`);
    source.addEventListener("open", () => setConnected(true));
    source.addEventListener("error", () => setConnected(false));
    source.addEventListener("snapshot", (event) => {
      const snapshot = read<{ entries: NetworkEntry[]; logs: LogEntry[] }>(
        event,
      );
      setEntries(snapshot.entries.slice().reverse().slice(0, LIMIT));
      setHeld([]);
      const fromBrowser = (list: LogEntry[]) =>
        list.filter((log) => log.source === "browser");
      setLogs((current) => mergeLogs(fromBrowser(current), snapshot.logs));
      setHeldLogs(fromBrowser);
    });
    source.addEventListener("entry", (event) => {
      const entry = read<NetworkEntry>(event);
      if (pausedRef.current) {
        setHeld((current) => [entry, ...current].slice(0, LIMIT));
      } else {
        setEntries((current) => [entry, ...current].slice(0, LIMIT));
      }
    });
    source.addEventListener("update", (event) => {
      const entry = read<NetworkEntry>(event);
      const replace = (list: NetworkEntry[]) =>
        list.map((item) => (item.id === entry.id ? entry : item));
      setEntries(replace);
      setHeld(replace);
    });
    source.addEventListener("log", (event) => addLogs([read<LogEntry>(event)]));
    source.addEventListener("clear", (event) => {
      if (read<View>(event) === "logs") {
        clearBrowserLogs();
        setLogs([]);
        setHeldLogs([]);
      } else {
        setEntries([]);
        setHeld([]);
        setSelectedId(null);
      }
    });

    const unsubscribe = subscribeBrowserLogs(addLogs);
    return () => {
      source.close();
      unsubscribe();
    };
  }, [endpoint]);

  const errors = useMemo(
    () =>
      entries.filter((entry) => {
        const bucket = statusClass(entry);
        return bucket !== "2xx" && bucket !== "3xx";
      }).length + logs.filter((log) => log.level === "error").length,
    [entries, logs],
  );
  const unseenErrors = open ? 0 : Math.max(0, errors - seenErrors);

  function toggle(next = !open) {
    setOpen(next);
    if (next) {
      setSeenErrors(errors);
      const search = view === "logs" ? logSearchRef : searchRef;
      // Next frame, so focusing does not scroll a panel mid-slide.
      window.requestAnimationFrame(() => search.current?.focus());
    }
  }

  // Alt+Shift+N: Cmd/Ctrl shortcuts belong to the browser and the app.
  const onKey = useEffectEvent((event: KeyboardEvent) => {
    if (event.altKey && event.shiftKey && event.code === "KeyN") {
      event.preventDefault();
      toggle();
    }
  });
  useEffect(() => {
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function resume() {
    setEntries((current) => [...held, ...current].slice(0, LIMIT));
    setHeld([]);
    setLogs((current) => mergeLogs(current, heldLogs));
    setHeldLogs([]);
    setPaused(false);
  }

  async function clear() {
    // The server broadcasts "clear", which empties every open tab's list.
    await fetch(`${endpoint}?kind=${view}`, { method: "DELETE" }).catch(
      () => null,
    );
  }

  const counts = useMemo(() => {
    const tally: Record<Filter, number> = {
      all: entries.length,
      "2xx": 0,
      "4xx": 0,
      "5xx": 0,
      failed: 0,
    };
    for (const entry of entries) {
      const bucket = statusClass(entry);
      if (bucket === "2xx" || bucket === "3xx") tally["2xx"] += 1;
      else tally[bucket] += 1;
    }
    return tally;
  }, [entries]);

  const groups = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matches = (entry: NetworkEntry) => {
      const bucket = statusClass(entry);
      const inFilter =
        filter === "all" ||
        bucket === filter ||
        (filter === "2xx" && bucket === "3xx");
      if (!inFilter) return false;
      if (!needle) return true;
      return [
        entry.method,
        entry.path,
        String(entry.status ?? ""),
        entry.requestId ?? "",
        entry.code ?? "",
        entry.upstreamRequestId ?? "",
        entry.outcome,
      ].some((value) => value.toLowerCase().includes(needle));
    };
    return bursts(entries)
      .map((burst) => ({
        ...burst,
        shown: burst.calls.filter((call) => matches(call.entry)),
      }))
      .filter((burst) => burst.shown.length > 0);
  }, [entries, query, filter]);

  const shorten = useMemo(() => {
    const rules = (shortenPaths ?? []).map(({ pattern, replacement }) => ({
      pattern: new RegExp(pattern),
      replacement,
    }));
    return (path: string) =>
      rules.reduce(
        (out, rule) => out.replace(rule.pattern, rule.replacement),
        path,
      );
  }, [shortenPaths]);

  const filtering = filter !== "all" || query.trim() !== "";

  function toggleBurst(key: number) {
    setOpenBursts((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  const selected =
    selectedId === null
      ? undefined
      : entries.find((entry) => entry.id === selectedId);
  const heldCount = held.length + heldLogs.length;

  return (
    <>
      <button
        type="button"
        onClick={() => toggle()}
        aria-expanded={open}
        aria-controls="devtools-panel"
        title="Server devtools (Alt+Shift+N)"
        className={cn("pill", open && "open")}
        style={{ bottom }}
      >
        <span aria-hidden className={cn("dot", connected && "live")} />
        Network
        <span className="num">{entries.length}</span>
        {unseenErrors > 0 ? (
          <span className="badge">{unseenErrors}</span>
        ) : null}
      </button>

      <aside
        id="devtools-panel"
        aria-label="Server devtools"
        inert={!open}
        onKeyDown={(event) => {
          if (event.key !== "Escape") return;
          event.stopPropagation();
          if (view === "network" && selectedId !== null) setSelectedId(null);
          else toggle(false);
        }}
        className={cn("panel", open && "open")}
      >
        <header className="header">
          <span aria-hidden className={cn("dot", connected && "live")} />
          <div role="tablist" aria-label="View" className="views">
            {VIEWS.map(({ id, label }) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={view === id}
                onClick={() => setView(id)}
                className="view"
              >
                {label}
                <span className="view-count">
                  {id === "network" ? entries.length : logs.length}
                </span>
              </button>
            ))}
          </div>
          <span className="subtitle truncate">
            {!connected
              ? "reconnecting…"
              : view === "network"
                ? "server fetch calls"
                : "server and browser console"}
          </span>
          <span className="actions">
            <PanelButton onClick={paused ? resume : () => setPaused(true)}>
              {paused
                ? `Resume${heldCount ? ` · ${heldCount} new` : ""}`
                : "Pause"}
            </PanelButton>
            <PanelButton onClick={clear}>Clear</PanelButton>
            <PanelButton onClick={() => toggle(false)} aria-label="Close">
              ✕
            </PanelButton>
          </span>
        </header>

        {view === "network" && selected ? (
          <Detail
            entry={selected}
            tab={tab}
            onTab={setTab}
            onBack={() => setSelectedId(null)}
          />
        ) : null}
        {view === "network" && !selected ? (
          <>
            <div className="toolbar">
              <SearchInput
                ref={searchRef}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search path, method, status, request id, code"
                aria-label="Search calls"
              />
              <div className="chips" role="group">
                {FILTERS.map(({ id, label }) => (
                  <FilterChip
                    key={id}
                    label={label}
                    count={counts[id]}
                    pressed={filter === id}
                    onClick={() => setFilter(id)}
                  />
                ))}
              </div>
            </div>

            <ol className="list">
              {groups.length === 0 ? (
                <li className="empty">
                  {entries.length === 0
                    ? "No calls yet. Every fetch this server makes shows up here as it happens."
                    : "Nothing matches."}
                </li>
              ) : (
                groups.map((burst) => {
                  const key = burst.calls[0].entry.id;
                  const isOpen = filtering || openBursts.has(key);
                  return (
                    <li key={key} className="burst">
                      <button
                        type="button"
                        aria-expanded={isOpen}
                        onClick={() => toggleBurst(key)}
                        className="burst-row"
                      >
                        <ChevronIcon
                          className={cn("chevron", isOpen && "open")}
                        />
                        <span className="num">
                          {clock(burst.calls[0].entry.at)}
                        </span>
                        <span className="summary">
                          {burst.calls.length}{" "}
                          {burst.calls.length === 1 ? "call" : "calls"}
                          {burst.sequential > 1 ? (
                            <span
                              title="The longest run of calls where each started after the one before it finished. Each one costs a full round trip."
                              className={cn(
                                "seq",
                                burst.sequential >= 3 && "slow",
                              )}
                            >
                              {" "}
                              · {burst.sequential} in sequence
                            </span>
                          ) : null}
                        </span>
                        <Timeline burst={burst} />
                        <span className="num right">
                          {duration(burst.end - burst.start)}
                        </span>
                      </button>
                      {isOpen ? (
                        <ol className="calls">
                          {burst.shown.map((call) => (
                            <li key={call.entry.id}>
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedId(call.entry.id);
                                  setTab("overview");
                                }}
                                className="call"
                              >
                                <span className="num">
                                  +{duration(call.start - burst.start)}
                                </span>
                                <MethodTag method={call.entry.method} />
                                <StatusTag entry={call.entry} />
                                <span
                                  className="path truncate"
                                  title={call.entry.path}
                                >
                                  {shorten(call.entry.path)}
                                </span>
                                <span className="num right">
                                  {duration(call.entry.durationMs)}
                                </span>
                              </button>
                            </li>
                          ))}
                        </ol>
                      ) : null}
                    </li>
                  );
                })
              )}
            </ol>
          </>
        ) : null}
        {/* Kept mounted, so its filters survive a trip to Network. */}
        <Logs logs={logs} hidden={view !== "logs"} searchRef={logSearchRef} />
      </aside>
    </>
  );
}

type Call = { entry: NetworkEntry; start: number; end: number };
type Burst = { calls: Call[]; start: number; end: number; sequential: number };

/** Calls that overlap or follow within this gap are one burst: a page render, or an action and its revalidation. */
const BURST_GAP_MS = 150;

/** Newest burst first; oldest call first inside each. */
function bursts(entries: NetworkEntry[]): Burst[] {
  const calls = entries
    .map((entry) => {
      const start = Date.parse(entry.at);
      return { entry, start, end: start + entry.durationMs };
    })
    .sort((a, b) => a.start - b.start);

  const groups: Burst[] = [];
  for (const call of calls) {
    const last = groups.at(-1);
    if (last && call.start <= last.end + BURST_GAP_MS) {
      last.calls.push(call);
      last.end = Math.max(last.end, call.end);
    } else {
      groups.push({
        calls: [call],
        start: call.start,
        end: call.end,
        sequential: 1,
      });
    }
  }
  for (const group of groups) group.sequential = longestChain(group.calls);
  return groups.reverse();
}

/** The most calls in a row that each started after the previous one finished. */
function longestChain(calls: Call[]): number {
  const depth = calls.map(() => 1);
  calls.forEach((call, i) => {
    for (let j = 0; j < i; j++) {
      if (calls[j].end <= call.start) {
        depth[i] = Math.max(depth[i], depth[j] + 1);
      }
    }
  });
  return Math.max(...depth);
}

const BAR_TONE: Record<StatusClass, string> = {
  "2xx": "ok",
  "3xx": "muted",
  "4xx": "warn",
  "5xx": "error",
  failed: "error",
};

function Timeline({ burst }: { burst: Burst }) {
  const span = Math.max(burst.end - burst.start, 1);
  return (
    <span aria-hidden className="timeline">
      {burst.calls.map((call) => (
        <span key={call.entry.id} className="lane">
          <span
            className={cn("bar", BAR_TONE[statusClass(call.entry)])}
            style={{
              left: `${((call.start - burst.start) / span) * 100}%`,
              width: `${((call.end - call.start) / span) * 100}%`,
            }}
          />
        </span>
      ))}
    </span>
  );
}

function Logs({
  logs,
  hidden,
  searchRef,
}: {
  logs: LogEntry[];
  hidden: boolean;
  searchRef: Ref<HTMLInputElement>;
}) {
  const [query, setQuery] = useState("");
  const [source, setSource] = useState<SourceFilter>("all");
  const [level, setLevel] = useState<LevelFilter>("all");
  const [expanded, setExpanded] = useState<string | null>(null);

  const counts = useMemo(() => {
    const tally = {
      all: logs.length,
      server: 0,
      browser: 0,
      error: 0,
      warn: 0,
    };
    for (const log of logs) {
      tally[log.source] += 1;
      if (log.level === "error" || log.level === "warn") tally[log.level] += 1;
    }
    return tally;
  }, [logs]);

  const shown = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return logs.filter(
      (log) =>
        (source === "all" || log.source === source) &&
        (level === "all" || log.level === level) &&
        (!needle || log.message.toLowerCase().includes(needle)),
    );
  }, [logs, query, source, level]);

  return (
    <div hidden={hidden} className="view-body">
      <div className="toolbar">
        <SearchInput
          ref={searchRef}
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search messages"
          aria-label="Search logs"
        />
        <div className="chips" role="group">
          {SOURCE_FILTERS.map(({ id, label }) => (
            <FilterChip
              key={id}
              label={label}
              count={counts[id]}
              pressed={source === id}
              onClick={() => setSource(id)}
            />
          ))}
          <span aria-hidden className="divider" />
          {LEVEL_FILTERS.map(({ id, label }) => (
            <FilterChip
              key={id}
              label={label}
              count={counts[id]}
              pressed={level === id}
              onClick={() => setLevel(id)}
            />
          ))}
        </div>
      </div>

      <ol className="list">
        {shown.length === 0 ? (
          <li className="empty">
            {logs.length === 0
              ? "No logs yet. Server and browser console output shows up here as it happens."
              : "Nothing matches."}
          </li>
        ) : (
          shown.map((log) => {
            const key = `${log.source}-${log.id}`;
            const isOpen = expanded === key;
            return (
              <li key={key} className="log">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setExpanded(isOpen ? null : key)}
                  className="log-row"
                >
                  <span className="num">{clock(log.at)}</span>
                  <Tag tone="neutral" upper>
                    {log.source}
                  </Tag>
                  <Tag tone={LEVEL_TONE[log.level]}>{log.level}</Tag>
                  <span className="path truncate">
                    {log.message.split("\n")[0]}
                  </span>
                </button>
                {isOpen ? (
                  <div className="log-open">
                    <Json value={formatLog(log.args, true)} />
                  </div>
                ) : null}
              </li>
            );
          })
        )}
      </ol>
    </div>
  );
}

/** Newest first, one copy of each log. */
function mergeLogs(current: LogEntry[], added: LogEntry[]): LogEntry[] {
  const byKey = new Map(current.map((log) => [`${log.source}-${log.id}`, log]));
  for (const log of added) byKey.set(`${log.source}-${log.id}`, log);
  return [...byKey.values()]
    .sort((a, b) => b.at.localeCompare(a.at))
    .slice(0, LOG_LIMIT);
}

function Detail({
  entry,
  tab,
  onTab,
  onBack,
}: {
  entry: NetworkEntry;
  tab: Tab;
  onTab: (tab: Tab) => void;
  onBack: () => void;
}) {
  const overview: [string, ReactNode][] = [
    ["URL", <Mono key="url">{entry.url}</Mono>],
    ["Method", entry.method],
    ["Status", entry.status ?? "no response"],
    ["Outcome", entry.outcome],
    ["Duration", duration(entry.durationMs)],
    ["Sent", new Date(entry.at).toLocaleString("en-GB")],
  ];
  if (entry.requestId) {
    overview.push(["Request id", <Mono key="rid">{entry.requestId}</Mono>]);
  }
  if (entry.upstreamRequestId) {
    overview.push([
      "Upstream request id",
      <Mono key="urid">{entry.upstreamRequestId}</Mono>,
    ]);
  }
  if (entry.code) overview.push(["Code", entry.code]);
  if (entry.cause) overview.push(["Cause", entry.cause]);
  if (entry.contentType) overview.push(["Content type", entry.contentType]);
  if (entry.responseSize !== undefined) {
    overview.push(["Response size", bytes(entry.responseSize)]);
  }

  return (
    <div className="view-body">
      <div className="detail-top">
        <div className="line">
          <PanelButton onClick={onBack}>← All calls</PanelButton>
          <span className="push">
            <CopyButton value={asCurl(entry)}>Copy as cURL</CopyButton>
            <CopyButton value={JSON.stringify(entry, null, 2)}>
              Copy JSON
            </CopyButton>
          </span>
        </div>
        <div className="line">
          <MethodTag method={entry.method} />
          <StatusTag entry={entry} />
          <span className="detail-path">{entry.path}</span>
        </div>
        <div role="tablist" className="tabs">
          {(["overview", "request", "response"] as const).map((id) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => onTab(id)}
              className="tab"
            >
              {id}
            </button>
          ))}
        </div>
      </div>

      <div className="detail-body">
        {tab === "overview" ? (
          <div className="stack">
            <Rows rows={overview} />
            {entry.issues ? (
              <Section title="Issues">
                <Json value={entry.issues} />
              </Section>
            ) : null}
          </div>
        ) : tab === "request" ? (
          <div className="stack">
            <Section title="Headers">
              <Rows
                rows={Object.entries(entry.requestHeaders).map(
                  ([name, value]) => [name, <Mono key={name}>{value}</Mono>],
                )}
              />
            </Section>
            <Section title="Body">
              {entry.requestBody === undefined ? (
                <p className="muted-text">No body</p>
              ) : (
                <Json value={entry.requestBody} />
              )}
            </Section>
          </div>
        ) : (
          <Section title="Body">
            {entry.responseBody === undefined ? (
              <p className="muted-text">
                {entry.outcome === "stream"
                  ? "A stream: its events are not recorded."
                  : "No body, or not JSON or text."}
              </p>
            ) : (
              <Json value={entry.responseBody} />
            )}
          </Section>
        )}
        <p className="note">
          Tokens, passwords, codes, card fields and private keys are redacted
          before they are recorded. Nothing here leaves this machine.
        </p>
      </div>
    </div>
  );
}

function PanelButton({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="button" {...props} className={cn("button", className)} />
  );
}

function CopyButton({
  value,
  children,
}: {
  value: string;
  children: ReactNode;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <PanelButton
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1400);
        } catch {
          // No clipboard permission; nothing worth showing.
        }
      }}
    >
      {copied ? "Copied" : children}
    </PanelButton>
  );
}

function SearchInput(props: ComponentProps<"input">) {
  return <input type="search" {...props} className="search" />;
}

function FilterChip({
  label,
  count,
  pressed,
  onClick,
}: {
  label: string;
  count: number;
  pressed: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className="chip"
    >
      {label}
      <span className="num">{count}</span>
    </button>
  );
}

type Tone = "neutral" | "muted" | "ok" | "warn" | "error";

function Tag({
  tone,
  upper = false,
  title,
  children,
}: {
  tone: Tone;
  upper?: boolean;
  title?: string;
  children: ReactNode;
}) {
  return (
    <span title={title} className={cn("tag", `tone-${tone}`, upper && "upper")}>
      {children}
    </span>
  );
}

function MethodTag({ method }: { method: string }) {
  return <Tag tone="neutral">{method}</Tag>;
}

const STATUS_TONE: Record<StatusClass, Tone> = {
  "2xx": "ok",
  "3xx": "muted",
  "4xx": "warn",
  "5xx": "error",
  failed: "error",
};

function StatusTag({ entry }: { entry: NetworkEntry }) {
  const label =
    entry.status ??
    (entry.outcome === "unreachable" ? "ERR" : entry.outcome.toUpperCase());
  return (
    <Tag tone={STATUS_TONE[statusClass(entry)]} title={entry.outcome}>
      {label}
    </Tag>
  );
}

const LEVEL_TONE: Record<LogLevel, Tone> = {
  error: "error",
  warn: "warn",
  info: "neutral",
  log: "neutral",
  debug: "muted",
};

function Rows({ rows }: { rows: [string, ReactNode][] }) {
  return (
    <dl className="rows">
      {rows.map(([label, value]) => (
        <div key={label} style={{ display: "contents" }}>
          <dt>{label}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="section">
      <h3 className="section-title">{title}</h3>
      {children}
    </section>
  );
}

function Json({ value }: { value: unknown }) {
  const text =
    typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return (
    <div className="json">
      <pre>{text}</pre>
      <button
        type="button"
        aria-label="Copy"
        onClick={() => navigator.clipboard.writeText(text).catch(() => null)}
        className="json-copy"
      >
        <CopyIcon />
      </button>
    </div>
  );
}

function Mono({ children }: { children: ReactNode }) {
  return <span className="mono">{children}</span>;
}

function ChevronIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={className}
    >
      <path d="M6.33333 4L10.3333 8L6.33333 12" />
    </svg>
  );
}

function CopyIcon() {
  return (
    <svg
      viewBox="0 0 15 15"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M11.25 5.3125H6.25C5.73223 5.3125 5.3125 5.73223 5.3125 6.25V11.25C5.3125 11.7678 5.73223 12.1875 6.25 12.1875H11.25C11.7678 12.1875 12.1875 11.7678 12.1875 11.25V6.25C12.1875 5.73223 11.7678 5.3125 11.25 5.3125Z" />
      <path d="M9.6875 5.3125V3.75C9.6875 3.50136 9.58873 3.2629 9.41291 3.08709C9.2371 2.91127 8.99864 2.8125 8.75 2.8125H3.75C3.50136 2.8125 3.2629 2.91127 3.08709 3.08709C2.91127 3.2629 2.8125 3.50136 2.8125 3.75V8.75C2.8125 8.99864 2.91127 9.2371 3.08709 9.41291C3.2629 9.58873 3.50136 9.6875 3.75 9.6875H5.3125" />
    </svg>
  );
}

function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

function clock(iso: string) {
  const at = new Date(iso);
  const pad = (n: number, width = 2) => String(n).padStart(width, "0");
  return `${pad(at.getHours())}:${pad(at.getMinutes())}:${pad(at.getSeconds())}.${pad(at.getMilliseconds(), 3)}`;
}

function duration(ms: number) {
  return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(2)} s`;
}

function bytes(count: number) {
  if (count < 1024) return `${count} B`;
  if (count < 1024 * 1024) return `${(count / 1024).toFixed(1)} kB`;
  return `${(count / 1024 / 1024).toFixed(1)} MB`;
}
